/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author minhn
 */
public class DonHang {
    private String maDH, maKH;
    private String maNV;
    private float tongTien;
    private String ngayDat; 

    public DonHang() {
    }

    public DonHang(String maDH, String maKH, String maNV, float tongTien, String ngayDat) {
        this.maDH = maDH;
        this.maKH = maKH;
        this.maNV = maNV;
        this.tongTien = tongTien;
        this.ngayDat = ngayDat;
    }

    public String getMaDH() {
        return maDH;
    }

    public void setMaDH(String maDH) {
        this.maDH = maDH;
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public float getTongTien() {
        return tongTien;
    }

    public void setTongTien(float tongTien) {
        this.tongTien = tongTien;
    }

    public String getNgayDat() {
        return ngayDat;
    }

    public void setNgayDat(String ngayDat) {
        this.ngayDat = ngayDat;
    }

    
}
