/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

import Model.NhanVien;

/**
 *
 * @author admin
 */
public class Auth {

    public static NhanVien user = null;

    public static void clear() {
        Auth.user = null;
    }

    public static boolean isLogin() {
        return Auth.user != null;
    }

    // Trả về vai trò (nếu có)
    public static String getRole() {
        return (Auth.isLogin() && user.getVaiTro() != null) ? user.getVaiTro() : "No Role";
    }

    // Kiểm tra có phải quản lý hay không
    public static boolean isManager() {
        return "Quản lý".equalsIgnoreCase(getRole());
    }
}
