package DAO;

import Model.NhanVien;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author minhn
 */
public class NhanVienDao {

    public boolean insert(NhanVien nv) {
        String sql = "INSERT INTO NHANVIEN (MaNV, HoTen, GioiTinh, SDT, VaiTro, MatKhau) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nv.getMaNV());
            ps.setString(2, nv.getHoTen());
            ps.setString(3, nv.getGioiTinh());
            ps.setString(4, nv.getSoDienThoai());
            ps.setString(5, nv.getVaiTro());
            ps.setString(6, nv.getMatkhau());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(NhanVien nv) {
        String sql = "UPDATE NHANVIEN SET HoTen = ?, GioiTinh = ?, SDT = ?, VaiTro = ?, MatKhau = ? WHERE MaNV = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nv.getHoTen());
            ps.setString(2, nv.getGioiTinh());
            ps.setString(3, nv.getSoDienThoai());
            ps.setString(4, nv.getVaiTro());
            ps.setString(5, nv.getMatkhau());
            ps.setString(6, nv.getMaNV());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(NhanVien nv) {
        String sql = "DELETE FROM NHANVIEN WHERE MaNV = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nv.getMaNV());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<NhanVien> findAll() {
        String sql = "SELECT * FROM NHANVIEN";
        List<NhanVien> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MaNV"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setSoDienThoai(rs.getString("SDT"));
                nv.setVaiTro(rs.getString("VaiTro"));
                nv.setMatkhau(rs.getString("MatKhau"));
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<NhanVien> findByID(String keyword) {
        String sql = "SELECT * FROM NHANVIEN WHERE MaNV LIKE ? OR SDT LIKE ?";
        List<NhanVien> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MaNV"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setSoDienThoai(rs.getString("SDT"));
                nv.setVaiTro(rs.getString("VaiTro"));
                nv.setMatkhau(rs.getString("MatKhau"));
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<NhanVien> findByMaNhanVien(String maNV) {
        String sql = "select * from NHANVIEN where MaNV = ?";
        List<NhanVien> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement pre = con.prepareStatement(sql)) {
            pre.setString(1, maNV);
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MaNV"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setSoDienThoai(rs.getString("SDT"));
                nv.setVaiTro(rs.getString("VaiTro"));
                nv.setMatkhau(rs.getString("MatKhau"));
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<NhanVien> findBySDT(String soDT) {
        String sql = "select * from NHANVIEN where SDT = ?";
        List<NhanVien> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement pre = con.prepareStatement(sql)) {
            pre.setString(1, soDT);
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getString("MaNV"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setSoDienThoai(rs.getString("SDT"));
                nv.setVaiTro(rs.getString("VaiTro"));
                nv.setMatkhau(rs.getString("MatKhau"));
                list.add(nv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public NhanVien getNhanVienByMaNV(String maNV) {
        String sql = "SELECT * FROM NHANVIEN WHERE MaNV = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maNV);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new NhanVien(
                        rs.getString("MaNV"),
                        rs.getString("HoTen"),
                        rs.getString("GioiTinh"),
                        rs.getString("SDT"),
                        rs.getString("VaiTro"),
                        rs.getString("MatKhau")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
