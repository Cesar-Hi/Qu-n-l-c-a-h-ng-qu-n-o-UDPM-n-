package DAO;

import Model.ChiTietDonHang;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ChiTietDonHangDao {

    public boolean insert(ChiTietDonHang ctdh) {
        String sql = "INSERT INTO CHITIETDONHANG (MaCTDH, MaDH, MaSP, SoLuong, DonGia) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, ctdh.getMaChiTietDonHang());
            ps.setString(2, ctdh.getMaDonHang());
            ps.setString(3, ctdh.getMaSanPham());
            ps.setInt(4, ctdh.getSoLuong());
            ps.setFloat(5, ctdh.getDonGia());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(String maCTDH, ChiTietDonHang ctdh) {
        String sql = "UPDATE CHITIETDONHANG SET MaDH = ?, MaSP = ?, SoLuong = ?, DonGia = ? WHERE MaCTDH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, ctdh.getMaDonHang());
            ps.setString(2, ctdh.getMaSanPham());
            ps.setInt(3, ctdh.getSoLuong());
            ps.setFloat(4, ctdh.getDonGia());
            ps.setString(5, maCTDH);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maCTDH) {
        String sql = "DELETE FROM CHITIETDONHANG WHERE MaCTDH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maCTDH);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<ChiTietDonHang> findAll() {
        List<ChiTietDonHang> list = new ArrayList<>();
        String sql = "SELECT * FROM CHITIETDONHANG";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ChiTietDonHang ctdh = new ChiTietDonHang(
                        rs.getString("MaCTDH"),
                        rs.getString("MaDH"),
                        rs.getString("MaSP"),
                        rs.getInt("SoLuong"),
                        rs.getFloat("DonGia"),
                        rs.getFloat("ThanhTien")
                );
                list.add(ctdh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<ChiTietDonHang> findByID(String maCTDH) {
        List<ChiTietDonHang> list = new ArrayList<>();
        String sql = "SELECT * FROM CHITIETDONHANG WHERE MaCTDH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maCTDH);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ChiTietDonHang ctdh = new ChiTietDonHang(
                        rs.getString("MaCTDH"),
                        rs.getString("MaDH"),
                        rs.getString("MaSP"),
                        rs.getInt("SoLuong"),
                        rs.getFloat("DonGia"),
                        rs.getFloat("ThanhTien")
                );
                list.add(ctdh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
