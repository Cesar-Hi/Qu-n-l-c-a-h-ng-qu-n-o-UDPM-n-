package DAO;

import Model.ChiTietHoaDon;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ChiTietHoaDonDao {

    public boolean insert(ChiTietHoaDon cthd) {
        String sql = "INSERT INTO CHITIETHOADON (MaCTHD, MaHD, MaSP, SoLuong, DonGia, MaDH) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, cthd.getMaChiTietHoaDon());
            ps.setString(2, cthd.getMaHoaDon());
            ps.setString(3, cthd.getMaSP());
            ps.setInt(4, cthd.getSoLuong());
            ps.setFloat(5, cthd.getDonGia());
            ps.setString(6, cthd.getMaDH());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(String maCTHD, ChiTietHoaDon cthd) {
        String sql = "UPDATE CHITIETHOADON SET MaHD = ?, MaSP = ?, SoLuong = ?, DonGia = ?, ThanhTien = ?, MaDH = ? WHERE MaCTHD = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, cthd.getMaHoaDon());
            ps.setString(2, cthd.getMaSP());
            ps.setInt(3, cthd.getSoLuong());
            ps.setFloat(4, cthd.getDonGia());
            ps.setFloat(5, cthd.getThanhTien());
            ps.setString(6, cthd.getMaDH());
            ps.setString(7, maCTHD);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maCTHD) {
        String sql = "DELETE FROM CHITIETHOADON WHERE MaCTHD = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maCTHD);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<ChiTietHoaDon> findAll() {
        String sql = "SELECT * FROM CHITIETHOADON";
        List<ChiTietHoaDon> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ChiTietHoaDon cthd = new ChiTietHoaDon();
                cthd.setMaChiTietHoaDon(rs.getString("MaCTHD"));
                cthd.setMaHoaDon(rs.getString("MaHD"));
                cthd.setMaSP(rs.getString("MaSP"));
                cthd.setSoLuong(rs.getInt("SoLuong"));
                cthd.setDonGia(rs.getFloat("DonGia"));
                cthd.setThanhTien(rs.getFloat("ThanhTien"));
                cthd.setMaDH(rs.getString("MaDH"));  
                list.add(cthd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<ChiTietHoaDon> findByID(String maCTHD) {
        String sql = "SELECT * FROM CHITIETHOADON WHERE MaCTHD = ?";
        List<ChiTietHoaDon> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maCTHD);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ChiTietHoaDon cthd = new ChiTietHoaDon();
                cthd.setMaChiTietHoaDon(rs.getString("MaCTHD"));
                cthd.setMaHoaDon(rs.getString("MaHD"));
                cthd.setMaSP(rs.getString("MaSP"));
                cthd.setSoLuong(rs.getInt("SoLuong"));
                cthd.setDonGia(rs.getFloat("DonGia"));
                cthd.setThanhTien(rs.getFloat("ThanhTien"));
                cthd.setMaDH(rs.getString("MaDH")); 
                list.add(cthd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
