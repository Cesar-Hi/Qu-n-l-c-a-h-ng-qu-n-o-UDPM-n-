package DAO;

import Model.HoaDon;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HoaDonDao {

    public boolean insert(HoaDon hd) {
        String sql = "INSERT INTO HOADON (MaHD, MaNV, MaKH, NgayTao, TongTien) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, hd.getMaHD());
            ps.setString(2, hd.getMaNV());
            ps.setString(3, hd.getMaKH());
            ps.setString(4, hd.getNgayTao());
            ps.setFloat(5, hd.getTongTien());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(String maHD, HoaDon hd) {
        String sql = "UPDATE HOADON SET MaNV = ?, MaKH = ?, NgayTao = ?, TongTien = ? WHERE MaHD = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, hd.getMaNV());
            ps.setString(2, hd.getMaKH());
            ps.setString(3, hd.getNgayTao());
            ps.setFloat(4, hd.getTongTien());
            ps.setString(5, maHD);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maHD) {
        String sql = "DELETE FROM HOADON WHERE MaHD = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maHD);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<HoaDon> findAll() {
        String sql = "SELECT * FROM HOADON";
        List<HoaDon> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHD(rs.getString("MaHD"));
                hd.setMaNV(rs.getString("MaNV"));
                hd.setMaKH(rs.getString("MaKH"));
                hd.setNgayTao(rs.getString("NgayTao"));
                hd.setTongTien(rs.getFloat("TongTien"));
                list.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static HoaDon findByID(String maHD) {
        String sql = "SELECT MaHD, MaNV, MaKH, NgayTao, TongTien FROM HOADON WHERE MaHD = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maHD);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHD(rs.getString("MaHD"));
                hd.setMaNV(rs.getString("MaNV"));
                hd.setMaKH(rs.getString("MaKH"));
                hd.setNgayTao(rs.getString("NgayTao"));
                hd.setTongTien(rs.getFloat("TongTien"));
                return hd;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<HoaDon> search(String keyword) {
        String sql = "SELECT MaHD, MaNV, MaKH, NgayTao, TongTien FROM HOADON WHERE MaHD LIKE ? OR MaKH LIKE ?";
        List<HoaDon> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHD(rs.getString("MaHD"));
                hd.setMaNV(rs.getString("MaNV"));
                hd.setMaKH(rs.getString("MaKH"));
                hd.setNgayTao(rs.getString("NgayTao"));
                hd.setTongTien(rs.getFloat("TongTien"));
                list.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
