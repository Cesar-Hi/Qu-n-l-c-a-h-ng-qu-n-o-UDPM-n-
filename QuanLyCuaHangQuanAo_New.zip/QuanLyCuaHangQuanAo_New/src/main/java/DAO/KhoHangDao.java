package DAO;

import Model.KhoHang;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO class for managing warehouse operations.
 */
public class KhoHangDao {

    public boolean insert(KhoHang kh) {
        String sql = "INSERT INTO KHOHANG (MaKho, TenKho, SoLuongTon, NgayNhap) VALUES (?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, kh.getMaKho());
            ps.setString(2, kh.getTenKho());
            ps.setInt(3, kh.getSoLuongTon());
            ps.setString(4, kh.getNgayNhap());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(String maKho, KhoHang kh) {
        String sql = "UPDATE KHOHANG SET TenKho = ?, SoLuongTon = ?, NgayNhap = ? WHERE MaKho = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(4, kh.getMaKho());
            ps.setString(1, kh.getTenKho());
            ps.setInt(2, kh.getSoLuongTon());
            ps.setString(3, kh.getNgayNhap());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maKho) {
        String sql = "DELETE FROM KHOHANG WHERE MaKho = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maKho);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<KhoHang> findAll() {
        String sql = "SELECT * FROM KHOHANG";
        List<KhoHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                KhoHang kh = new KhoHang();
                kh.setMaKho(rs.getString("MaKho"));
                kh.setTenKho(rs.getString("TenKho"));
                kh.setSoLuongTon(rs.getInt("SoLuongTon"));
                kh.setNgayNhap(rs.getString("NgayNhap"));
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<KhoHang> findByID(String maKho) {
        String sql = "SELECT * FROM KHOHANG WHERE MaKho = ?";
        List<KhoHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maKho);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                KhoHang kh = new KhoHang();
                kh.setMaKho(rs.getString("MaKho"));
                kh.setTenKho(rs.getString("TenKho"));
                kh.setSoLuongTon(rs.getInt("SoLuongTon"));
                kh.setNgayNhap(rs.getString("NgayNhap"));
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<KhoHang> search(String keyword) {
        String sql = "SELECT * FROM KHOHANG WHERE MaKho = ?";
        List<KhoHang> list = new ArrayList<>();

        try {
            Connection con = DataProvider.dataconnection();
            PreparedStatement preStm = con.prepareStatement(sql);
            preStm.setString(1, "%" + keyword + "%");
            ResultSet rs = preStm.executeQuery();

            while (rs.next()) {
                KhoHang kh = new KhoHang(
                        rs.getString("MaKho"),
                        rs.getString("TenKho"),
                        rs.getString("NgayNhap"),
                        rs.getInt("SoLuongTon")
                );
                list.add(kh);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }
}
