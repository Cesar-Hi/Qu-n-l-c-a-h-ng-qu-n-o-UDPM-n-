package DAO;

import Model.SanPham;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SanPhamDao {

    public boolean insert(SanPham sp) {
        String sql = "INSERT INTO SANPHAM (MaSP, TenSP, LoaiSP, DonGia, SoLuong, Size, MauSac, MaKho) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sp.getMaSP());
            ps.setString(2, sp.getTenSP());
            ps.setString(3, sp.getLoaiSP());
            ps.setFloat(4, sp.getDonGia());
            ps.setInt(5, sp.getSoLuong());
            ps.setString(6, sp.getSize());
            ps.setString(7, sp.getMauSac());

            ps.setString(8, sp.getMaKho());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(String maSP, SanPham sp) {
        String sql = "UPDATE SANPHAM SET TenSP = ?, LoaiSP = ?, DonGia = ?, SoLuong = ?, Size = ?, MauSac = ?, MaKho = ? WHERE MaSP = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sp.getTenSP());
            ps.setString(2, sp.getLoaiSP());
            ps.setFloat(3, sp.getDonGia());
            ps.setInt(4, sp.getSoLuong());
            ps.setString(5, sp.getSize());
            ps.setString(6, sp.getMauSac());
            ps.setString(7, sp.getMaKho());
            ps.setString(8, maSP);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maSP) {
        String sql = "DELETE FROM SANPHAM WHERE MaSP = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maSP);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<SanPham> findAll() {
        String sql = "SELECT * FROM SANPHAM";
        List<SanPham> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                SanPham sp = new SanPham();
                sp.setMaKho(rs.getString("MaKho"));
                sp.setMaSP(rs.getString("MaSP"));
                sp.setTenSP(rs.getString("TenSP"));
                sp.setLoaiSP(rs.getString("LoaiSP"));
                sp.setDonGia(rs.getFloat("DonGia"));
                sp.setSoLuong(rs.getInt("SoLuong"));
                sp.setSize(rs.getString("Size"));
                sp.setMauSac(rs.getString("MauSac"));
                list.add(sp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<SanPham> findByID(String maSP) {
        String sql = "SELECT * FROM SANPHAM WHERE MaSP = ?";
        List<SanPham> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maSP);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SanPham sp = new SanPham();
                sp.setMaKho(rs.getString("MaKho"));
                sp.setMaSP(rs.getString("MaSP"));
                sp.setTenSP(rs.getString("TenSP"));
                sp.setLoaiSP(rs.getString("LoaiSP"));
                sp.setDonGia(rs.getFloat("DonGia"));
                sp.setSoLuong(rs.getInt("SoLuong"));
                sp.setSize(rs.getString("Size"));
                sp.setMauSac(rs.getString("MauSac"));
                list.add(sp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
