package DAO;

import Model.KhachHang;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO for managing KhachHang (Customer) entities in the database.
 */
public class KhachHangDao {

    public boolean insert(KhachHang kh) {
        String sql = "INSERT INTO KHACHHANG (MaKH, HoTen, SDT, Email, DiaChi) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, kh.getMaKH());
            ps.setString(2, kh.getHoTen());
            ps.setString(3, kh.getSDT());
            ps.setString(4, kh.getEmail());
            ps.setString(5, kh.getDiaChi());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(KhachHang kh) {
        String sql = "UPDATE KHACHHANG SET HoTen = ?, SDT = ?, Email = ?, DiaChi = ? WHERE MaKH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, kh.getHoTen());
            ps.setString(2, kh.getSDT());
            ps.setString(3, kh.getEmail());
            ps.setString(4, kh.getDiaChi());
            ps.setString(5, kh.getMaKH());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maKH) {
        String sql = "DELETE FROM KHACHHANG WHERE MaKH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maKH);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<KhachHang> findAll() {
        String sql = "SELECT * FROM KHACHHANG";
        List<KhachHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                KhachHang kh = new KhachHang();
                kh.setMaKH(rs.getString("MaKH"));
                kh.setHoTen(rs.getString("HoTen"));
                kh.setSDT(rs.getString("SDT"));
                kh.setEmail(rs.getString("Email"));
                kh.setDiaChi(rs.getString("DiaChi"));
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static KhachHang findByID(String maKH) {
        String sql = "SELECT MaKH, HoTen, SDT, Email, DiaChi FROM KHACHHANG WHERE MaKH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maKH);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                KhachHang kh = new KhachHang();
                kh.setMaKH(rs.getString("MaKH"));
                kh.setHoTen(rs.getString("HoTen"));
                kh.setSDT(rs.getString("SDT"));
                kh.setEmail(rs.getString("Email"));
                kh.setDiaChi(rs.getString("DiaChi"));
                return kh;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<KhachHang> search(String keyword) {
        String sql = "SELECT MaKH, HoTen, SDT, Email, DiaChi FROM KHACHHANG WHERE MaKH LIKE ? OR SDT LIKE ?";
        List<KhachHang> list = new ArrayList<>();

        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                KhachHang kh = new KhachHang();
                kh.setMaKH(rs.getString("MaKH"));
                kh.setHoTen(rs.getString("HoTen"));
                kh.setSDT(rs.getString("SDT"));
                kh.setEmail(rs.getString("Email"));
                kh.setDiaChi(rs.getString("DiaChi"));
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

}
