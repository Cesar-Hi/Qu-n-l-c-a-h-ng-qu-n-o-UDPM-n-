package DAO;

import Model.DonHang;
import Utils.DataProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DonHangDao {

    public boolean insert(DonHang dh) {
        String sql = "INSERT INTO DONHANG (MaDH, MaKH, MaNV, NgayDat, TongTien) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dh.getMaDH());
            ps.setString(2, dh.getMaKH());
            ps.setString(3, dh.getMaNV());
            ps.setString(4, dh.getNgayDat());
            ps.setFloat(5, dh.getTongTien());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean update(String maDH, DonHang dh) {
        String sql = "UPDATE DONHANG SET MaKH = ?, MaNV = ?, NgayDat = ?, TongTien = ? WHERE MaDH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dh.getMaKH());
            ps.setString(2, dh.getMaNV());
            ps.setString(3, dh.getNgayDat());
            ps.setFloat(4, dh.getTongTien());
            ps.setString(5, maDH);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(String maDH) {
        String sql = "DELETE FROM DONHANG WHERE MaDH = ?";
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maDH);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static List<DonHang> findAll() {
        String sql = "SELECT * FROM DONHANG";
        List<DonHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                DonHang dh = new DonHang();
                dh.setMaDH(rs.getString("MaDH"));
                dh.setMaKH(rs.getString("MaKH"));
                dh.setMaNV(rs.getString("MaNV"));
                dh.setNgayDat(rs.getString("NgayDat"));
                dh.setTongTien(rs.getFloat("TongTien"));
                list.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<DonHang> findByID(String maDH) {
        String sql = "SELECT * FROM DONHANG WHERE MaDH = ?";
        List<DonHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maDH);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                DonHang dh = new DonHang();
                dh.setMaDH(rs.getString("MaDH"));
                dh.setMaKH(rs.getString("MaKH"));
                dh.setMaNV(rs.getString("MaNV"));
                dh.setNgayDat(rs.getString("NgayDat"));
                dh.setTongTien(rs.getFloat("TongTien"));
                list.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<DonHang> findByMaKH(String maKH) {
        String sql = "SELECT * FROM DONHANG WHERE MaKH = ?";
        List<DonHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maKH);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                DonHang dh = new DonHang();
                dh.setMaDH(rs.getString("MaDH"));
                dh.setMaKH(rs.getString("MaKH"));
                dh.setMaNV(rs.getString("MaNV"));
                dh.setNgayDat(rs.getString("NgayDat"));
                dh.setTongTien(rs.getFloat("TongTien"));
                list.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<DonHang> findByMaNV(String maNV) {
        String sql = "SELECT * FROM DONHANG WHERE MaNV = ?";
        List<DonHang> list = new ArrayList<>();
        try (Connection con = DataProvider.dataconnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maNV);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                DonHang dh = new DonHang();
                dh.setMaDH(rs.getString("MaDH"));
                dh.setMaKH(rs.getString("MaKH"));
                dh.setMaNV(rs.getString("MaNV"));
                dh.setNgayDat(rs.getString("NgayDat"));
                dh.setTongTien(rs.getFloat("TongTien"));
                list.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
